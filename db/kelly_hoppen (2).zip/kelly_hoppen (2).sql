-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 12, 2026 at 05:43 AM
-- Server version: 9.1.0
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kelly_hoppen`
--

-- --------------------------------------------------------

--
-- Table structure for table `master_category`
--

DROP TABLE IF EXISTS `master_category`;
CREATE TABLE IF NOT EXISTS `master_category` (
  `cate_id` int NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(255) NOT NULL,
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `master_category`
--

INSERT INTO `master_category` (`cate_id`, `cate_name`) VALUES
(1, 'End of white'),
(2, 'Color Series'),
(3, 'Stone Series'),
(4, 'Marble Series');

-- --------------------------------------------------------

--
-- Table structure for table `master_products`
--

DROP TABLE IF EXISTS `master_products`;
CREATE TABLE IF NOT EXISTS `master_products` (
  `id` int NOT NULL AUTO_INCREMENT,
  `cate_id` int NOT NULL,
  `model_name` varchar(255) NOT NULL,
  `code` varchar(100) NOT NULL,
  `length_mm` decimal(10,0) NOT NULL,
  `width_mm` decimal(10,0) NOT NULL,
  `height_mm` decimal(10,0) NOT NULL,
  `img1` varchar(255) NOT NULL,
  `img2` varchar(255) DEFAULT NULL,
  `img3` varchar(255) DEFAULT NULL,
  `img4` varchar(255) DEFAULT NULL,
  `img5` varchar(255) DEFAULT NULL,
  `txt1` text NOT NULL,
  `txt2` text,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_keyword` varchar(255) DEFAULT NULL,
  `meta_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `master_products`
--

INSERT INTO `master_products` (`id`, `cate_id`, `model_name`, `code`, `length_mm`, `width_mm`, `height_mm`, `img1`, `img2`, `img3`, `img4`, `img5`, `txt1`, `txt2`, `meta_title`, `meta_keyword`, `meta_description`) VALUES
(1, 1, 'ALBANY', 'RK10H-W', 420, 340, 160, 'albany copy.jpg', NULL, NULL, NULL, NULL, 'Luxury Layer', 'A Quality Wash Basin Merges Form With Fortitude. Crafted From Materials Of Superior Strength, It Ensures Resilience Against The Rigors Of Time. This Architectural Element Elevates The Bathroom, Serving As A Focal Point Where Enduring Elegance Meets Uncompromising Quality And Lasting Utility.', NULL, NULL, NULL),
(2, 1, 'ALVANTA', 'RK28H-W', 615, 335, 165, 'Alvanta copy.jpg', NULL, NULL, NULL, NULL, 'White Wisp', 'Defining the architectural standard, our wash basins are meticulously crafted from materials chosen for their unparalleled quality and inherent robustness. The exceptional strength ensures resistance to daily wear and heavy impacts, guaranteeing prolonged structural stability. This commitment to resilience allows the basin to transcend mere utility, becoming a permanent, reliable, and visually powerful feature in any sophisticated design scheme.', NULL, NULL, NULL),
(3, 1, 'ATLANTA', 'GK35H-W', 510, 355, 120, 'Alvanta copy.jpg', NULL, NULL, NULL, NULL, 'Shine Sustained', 'Our wash basins are the epitome of resilience meeting refinement. Sourced from high-density, superior-quality materials, they offer exceptional structural strength, preventing cracks and surface wear even in high-traffic environments. This engineering focus ensures that the fixture not only enhances the bathroomâ€™s aesthetic instantly but also promises a lifetime of robust, trouble-free use, aligning with the most stringent architectural specifications.', NULL, NULL, NULL),
(4, 1, 'ANTALYA(SLIM)', 'RK17H-W', 585, 340, 155, 'Antalya copy.jpg', NULL, NULL, NULL, NULL, 'Round Rhythm', NULL, NULL, NULL, NULL),
(5, 1, 'ARMANI', 'RK29H-W', 460, 460, 145, 'ARMANI copy.jpg', NULL, NULL, NULL, NULL, 'Elegant Curve', 'Our wash basins are the epitome of resilience meeting refinement. Sourced from high-density, superior-quality materials, they offer exceptional structural strength, preventing cracks and surface wear even in high-traffic environments. This engineering focus ensures that the fixture not only enhances the bathroomâ€™s aesthetic instantly but also promises a lifetime of robust, trouble-free use, aligning with the most stringent architectural specifications.', NULL, NULL, NULL),
(6, 1, 'AUCKLAND', 'SK12H-W', 420, 420, 110, 'Auckland copy.jpg', NULL, NULL, NULL, NULL, 'Design Define', 'Beyond aesthetics, the architectural wash basin is defined by durability. It is the result of precision engineering and high-quality materials, ensuring structural resilience. This dedication ensures the basin resists wear, maintaining its flawless finish and robust form for decades, an investment in lasting luxury.', NULL, NULL, NULL),
(7, 1, 'AUSTINA', 'RK01H-W', 405, 405, 140, 'austina copy.jpg', NULL, NULL, NULL, NULL, 'smooth serene', 'Engineered through controlled kiln-firing cycles and precision moulding to achieve uniform density, high impact resistance, and a flawlessly smooth glaze that maintains its clarity over prolonged exposure to water, cleaning agents, and daily mechanical useâ€”resulting in a basin that performs consistently while enhancing the structural discipline of modern interior design.', NULL, NULL, NULL),
(8, 1, 'BLACKPOOL', 'RK25H-W', 590, 370, 220, 'blackpool copy.jpg', NULL, NULL, NULL, NULL, 'Streamline Shape', 'We see the wash basin as a permanent fixture, not a temporary trend. Crafted for permanence, it features industrial-grade strength and the highest material quality achievable. This robust construction guarantees years of flawless performance, underscoring our dedication to creating architectural elements that are both highly durable and aesthetically timeless.', NULL, NULL, NULL),
(9, 1, 'BRAZZAVILLE', 'SK04H-W', 400, 400, 125, 'brazzaville copy.jpg', NULL, NULL, NULL, NULL, 'Artful Form', 'Engineered through controlled kiln-firing cycles and precision moulding to achieve uniform density, high impact resistance, and a flawlessly smooth glaze that maintains its clarity over prolonged exposure to water, cleaning agents, and daily mechanical useâ€”resulting in a basin that performs consistently while enhancing the structural discipline of modern interior design.', NULL, NULL, NULL),
(10, 1, 'BRETON(SLIM)', 'HK19H-W', 590, 350, 100, 'BRETON copy.jpg', NULL, NULL, NULL, NULL, 'Vessel Vibe', 'Every wash basin must be founded on uncompromising strength. High-grade materials ensure it endures constant use while preserving its inherent beauty.', NULL, NULL, NULL),
(11, 1, 'BRISTOL', 'GK38H-W', 600, 445, 160, 'BRISTOL copy.jpg', NULL, NULL, NULL, NULL, 'Smooth Serene', 'A Quality Wash Basin Merges Form With Fortitude. Crafted From Materials Of Superior Strength, It Ensures Resilience Against The Rigors Of Time. This Architectural Element Elevates The Bathroom, Serving As A Focal Point Where Enduring Elegance Meets Uncompromising Quality And Lasting Utility.', NULL, NULL, NULL),
(12, 1, 'CAPRI', 'GK41H-W', 790, 450, 150, 'Capri copy.jpg', NULL, NULL, NULL, NULL, 'Artful Form', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(13, 1, 'CAIRO', 'SK26H-W', 535, 360, 125, 'cario copy.jpg', NULL, NULL, NULL, NULL, 'Chiseled Charm', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(14, 1, 'CAROLINA', 'RK21H-W', 550, 350, 155, 'carolina copy.jpg', NULL, NULL, NULL, NULL, 'Defined Dimension', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(15, 1, 'CENTURIA', 'XK44H-W', 850, 450, 135, 'centuria copy.jpg', NULL, NULL, NULL, NULL, 'Perfect Pour', 'A Quality Wash Basin Merges Form With Fortitude. Crafted From Materials Of Superior Strength, It Ensures Resilience Against The Rigors Of Time. This Architectural Element Elevates The Bathroom, Serving As A Focal Point Where Enduring Elegance Meets Uncompromising Quality And Lasting Utility.', NULL, NULL, NULL),
(16, 1, 'COLISEO', 'XK45H-W', 650, 460, 115, 'coliseo copy.jpg', NULL, NULL, NULL, NULL, 'Silken Smooth', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(17, 1, 'COLOMBO', 'RK14H-W', 400, 400, 115, 'colombo copy.jpg', NULL, NULL, NULL, NULL, 'Touch Tranquil', NULL, NULL, NULL, NULL),
(18, 1, 'COLORADO', 'RK15H-W', 600, 400, 120, 'colorado copy.jpg', NULL, NULL, NULL, NULL, 'Shine Shield', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(19, 1, 'DALLAS', 'SK16H-W', 395, 395, 100, 'dallas copy.jpg', NULL, NULL, NULL, NULL, 'Square Sculpt', 'Beyond aesthetics, the architectural wash basin is defined by durability. It is the result of precision craftsmanship and materials selected for their extreme quality and structural resilience. This dedication ensures the basin resists wear, maintaining its flawless finish and robust form for decades.', NULL, NULL, NULL),
(20, 1, 'DERBAN', 'RK06H-W', 360, 360, 130, 'derban copy.jpg', NULL, NULL, NULL, NULL, 'Solid Style', 'A Quality Wash Basin Merges Form With Fortitude. Crafted From Materials Of Superior Strength, It Ensures Resilience Against The Rigors Of Time. This Architectural Element Elevates The Bathroom, Serving As A Focal Point Where Enduring Elegance Meets Uncompromising Quality And Lasting Utility.', NULL, NULL, NULL),
(21, 1, 'DUBLIN', 'GK02H-W', 460, 295, 115, 'Dublin copy.jpg', NULL, NULL, NULL, NULL, 'Wonder white', NULL, NULL, NULL, NULL),
(22, 1, 'DURRES', 'SK32H-W', 495, 300, 130, 'Durres copy.jpg', NULL, NULL, NULL, NULL, 'Vitreous Virtue', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(23, 1, 'FLORENCE', 'RK07H-W', 590, 390, 140, 'florance copy.jpg', NULL, NULL, NULL, NULL, 'Perfect Pour', NULL, NULL, NULL, NULL),
(24, 1, 'FURMAX', 'GK46H-W', 795, 450, 160, 'furmax copy.jpg', NULL, NULL, NULL, NULL, 'White Wonder', 'A Quality Wash Basin Merges Form With Fortitude. Crafted From Materials Of Superior Strength, It Ensures Resilience Against The Rigors Of Time. This Architectural Element Elevates The Bathroom, Serving As A Focal Point Where Enduring Elegance Meets Uncompromising Quality And Lasting Utility.', NULL, NULL, NULL),
(25, 1, 'GERMISTON', 'RK13H-W', 590, 345, 155, 'germiston copy.jpg', NULL, NULL, NULL, NULL, 'Simply Stunning', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(26, 1, 'HATRIA', 'GK40H-W', 395, 395, 135, 'hatria copy.jpg', NULL, NULL, NULL, NULL, 'Shape Symphony', NULL, NULL, NULL, NULL),
(27, 1, 'HAVANA', 'RK22H-W', 520, 375, 150, 'HAVANA copy.jpg', NULL, NULL, NULL, NULL, 'Balanced Build Havana', 'Engineered through controlled kiln-firing cycles and precision moulding to achieve uniform density, high impact resistance, and a flawlessly smooth glaze that maintains its clarity over prolonged exposure to water, cleaning agents, and daily mechanical useâ€”resulting in a basin that performs consistently while enhancing the structural discipline of modern interior design.', NULL, NULL, NULL),
(28, 1, 'HOWRAH', 'RK33H-W', 530, 400, 145, 'Howrah copy.jpg', NULL, NULL, NULL, NULL, 'Impervious Ideal', 'A truly superior wash basin represents an investment in durability, not just design. Engineered with exceptional structural strength, it resists chipping and thermal shock, reflecting top-tier manufacturing quality. This robust construction ensures the basin functions reliably and retains its pristine, architectural-grade surface over decades, confirming its place as a lasting cornerstone of the modern bathroom.', NULL, NULL, NULL),
(29, 1, 'KELOWNA(SLIM)', 'RK18H-W', 550, 320, 165, 'Kelowna copy.jpg', NULL, NULL, NULL, NULL, 'Curved Class', 'Engineered through controlled kiln-firing cycles and precision moulding to achieve uniform density, high impact resistance, and a flawlessly smooth glaze that maintains its clarity over prolonged exposure to water.', NULL, NULL, NULL),
(30, 1, 'KEYSTONE', 'RK30H-W', 350, 350, 110, 'kEYSTONE copy.jpg', NULL, NULL, NULL, NULL, 'Design Depth', 'A Quality Wash Basin Merges Form With Fortitude. Crafted From Materials Of Superior Strength, It Ensures Resilience Against The Rigors Of Time. This Architectural Element Elevates The Bathroom, Serving As A Focal Point Where Enduring Elegance Meets Uncompromising Quality And Lasting Utility.', NULL, NULL, NULL),
(31, 1, 'KINGSTON', 'SK11H-W', 595, 380, 110, 'Kingstone copy.jpg', NULL, NULL, NULL, NULL, 'Lasting Luster', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(32, 1, 'KYOTO', 'HK05H-W', 590, 375, 105, 'kyoto copy.jpg', NULL, NULL, NULL, NULL, 'Clean Curve', 'A Quality Wash Basin Merges Form With Fortitude. Crafted From Materials Of Superior Strength, It Ensures Resilience Against The Rigors Of Time. This Architectural Element Elevates The Bathroom, Serving As A Focal Point Where Enduring Elegance Meets Uncompromising Quality And Lasting Utility.', NULL, NULL, NULL),
(33, 1, 'LIVERPOOL', 'RK36H-W', 590, 395, 130, 'liverpool copy.jpg', NULL, NULL, NULL, NULL, 'Premium Piece', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(34, 1, 'LUTFU', 'GK31H-W', 510, 360, 120, 'luftu-render copy.jpg', NULL, NULL, NULL, NULL, 'Quiet Quality', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(35, 1, 'MALMO', 'SK08H-W', 445, 345, 110, 'malmo copy.jpg', NULL, NULL, NULL, NULL, 'Silken Smooth', 'Every wash basin must be founded on uncompromising strength. High-grade materials ensure it endures constant use while preserving its inherent beauty. In the realm of quality architecture, this fixture is not merely an accessory; it is a vital, strong, and enduring element that guarantees superior, long-term function and style.', NULL, NULL, NULL),
(36, 1, 'MANILA', 'RK34H-W', 590, 410, 105, 'manila copy.jpg', NULL, NULL, NULL, NULL, 'Lifetime Look', 'Defining the architectural standard, our wash basins are meticulously crafted from materials chosen for their unparalleled quality and inherent robustness. The exceptional strength ensures resistance to daily wear and heavy impacts, guaranteeing prolonged structural stability. This commitment to resilience allows the basin to transcend mere utility, becoming a permanent, reliable, and visually powerful feature in any sophisticated design scheme.', NULL, NULL, NULL),
(37, 1, 'MIAMI', 'RK23H-W', 450, 450, 145, 'miami copy.jpg', NULL, NULL, NULL, NULL, 'Contour Craft', 'Architectural excellence relies on components built to last. Our wash basins are engineered for maximum structural reliability, using materials of unparalleled quality. This ensures they maintain their pristine condition and structural integrity against daily wear, serving as robust, beautiful foundations that elevate the entire design scheme indefinitely.', NULL, NULL, NULL),
(38, 1, 'MONACO', 'HK03H-W', 590, 395, 140, 'monaco copy.jpg', NULL, NULL, NULL, NULL, 'Shape Symphony', 'A Quality Wash Basin Merges Form With Fortitude. Crafted From Materials Of Superior Strength, It Ensures Resilience Against The Rigors Of Time. This Architectural Element Elevates The Bathroom, Serving As A Focal Point Where Enduring Elegance Meets Uncompromising Quality And Lasting Utility.', NULL, NULL, NULL),
(39, 1, 'MOROCCO', 'RK09H-W', 590, 395, 125, 'morocco copy.jpg', NULL, NULL, NULL, NULL, 'Enduring Edge', 'The wash basin powerfully defines the bathroom\'s character. Its quality is judged by the depth of its material strength and resilience to impact. We craft it not just to hold water, but to hold the integrity of the design, ensuring a structure that is as robust as it is visually striking and architecturally sound.', NULL, NULL, NULL),
(40, 1, 'PLATOS', 'RK39H-W', 510, 335, 130, 'PLATOS copy.jpg', NULL, NULL, NULL, NULL, 'White Wonder', 'A Quality Wash Basin Merges Form With Fortitude. Crafted From Materials Of Superior Strength, It Ensures Resilience Against The Rigors Of Time. This Architectural Element Elevates The Bathroom, Serving As A Focal Point Where Enduring Elegance Meets Uncompromising Quality And Lasting Utility.', NULL, NULL, NULL),
(41, 1, 'POMPEYA', 'GK42H-W', 750, 405, 155, 'pompeya copy.jpg', NULL, NULL, NULL, NULL, 'Smooth Serene', NULL, NULL, NULL, NULL),
(42, 1, 'RIGA', 'RK37H-W', 890, 395, 115, 'Riga copy.jpg', NULL, NULL, NULL, NULL, 'Gallery Glaze', NULL, NULL, NULL, NULL),
(43, 1, 'TORINO(SLIM)', 'SK20H-W', 390, 390, 110, 'Torino copy.jpg', NULL, NULL, NULL, NULL, 'Minimal Model', 'The wash basin powerfully defines the bathroom\'s character and ensures lasting utility.', NULL, NULL, NULL),
(44, 1, 'TORONTO', 'RK24H-W', 565, 435, 145, 'toronto copy.jpg', NULL, NULL, NULL, NULL, 'Streamline Shape', 'Architectural excellence relies on components built to last. Our wash basins are engineered for maximum structural reliability, using materials of unparalleled quality. This ensures they maintain their pristine condition and structural integrity against daily wear, serving as robust, beautiful foundations that elevate the entire design scheme indefinitely.', NULL, NULL, NULL),
(45, 1, 'VIENNA', 'SK27H-W', 450, 450, 130, 'Vienna copy.jpg', NULL, NULL, NULL, NULL, 'Sculpted Shine', 'A truly superior wash basin represents an investment in durability, not just design. Engineered with exceptional structural strength, it resists chipping and thermal shock, reflecting top-tier manufacturing quality. This robust construction ensures the basin functions reliably and retains its pristine, architectural-grade surface over decades, confirming its place as a lasting cornerstone of the modern bathroom.', NULL, NULL, NULL),
(46, 1, 'MUTSU', 'GK43H-W', 495, 350, 315, '', NULL, NULL, NULL, NULL, 'Fresh Focus', NULL, NULL, NULL, NULL),
(47, 2, 'DERBAN PEACOCK BLUE ', 'RK06H-PB', 360, 360, 130, 'derban - peacock blue.png', '', NULL, NULL, NULL, 'DERBAN PEACOCK BLUE ', 'We elevate the wash basin beyond ordinary utility. It is designed as a masterpiece of structural engineering, featuring unparalleled quality and substantial strength for maximum stability. This robust construction is essential for high-end applications, ', NULL, NULL, NULL),
(48, 2, 'DERBAN NIPPON GRAY ', 'RK06H-NB', 360, 360, 130, 'derban -nippon gray.png', NULL, NULL, NULL, NULL, 'DERBAN NIPPON GRAY ', 'Defining the architectural standard, our wash basins are meticulously crafted from materials chosen for their unparalleled quality and inherent robustness. The exceptional strength ensures resistance to daily wear and heavy impacts, guaranteeing prolonged structural stability. This commitment to resilience allows the basin to transcend mere utility, becoming a permanent, reliable, and visually powerful feature in any sophisticated design scheme.', NULL, NULL, NULL),
(49, 2, 'DERBAN PERKY PINK', 'RK06H-PP', 360, 360, 130, 'derban -perky pink.png', NULL, NULL, NULL, NULL, 'DERBAN PERKY PINK', 'Defining the architectural standard, our wash basins are meticulously crafted from materials chosen for their unparalleled quality and inherent robustness. The exceptional strength ensures resistance to daily wear and heavy impacts, guaranteeing prolonged structural stability. This commitment to resilience allows the basin to transcend mere utility, becoming a permanent, reliable, and visually powerful feature in any sophisticated design scheme.', NULL, NULL, NULL),
(50, 2, 'DERBAN ALICE BLUE ', 'RK06H-AB', 360, 360, 130, 'derban-alice blue.png', NULL, NULL, NULL, NULL, 'DERBAN ALICE BLUE ', 'We elevate the wash basin beyond ordinary utility. It is designed as a masterpiece of structural engineering, featuring unparalleled quality and substantial strength for maximum stability. This robust construction is essential for high-end applications, providing peace of mind and enduring performance. It is a refined, reliable fixture that perfectly complements a vision of lasting architectural integrity.', NULL, NULL, NULL),
(51, 2, 'DERBAN COTTON WHITE ', 'RK06H-AB', 360, 360, 130, 'derban-cotton white.png', NULL, NULL, NULL, NULL, 'DERBAN COTTON WHITE ', 'We elevate the wash basin beyond ordinary utility. It is designed as a masterpiece of structural engineering, featuring unparalleled quality and substantial strength for maximum stability. This robust construction is essential for high-end applications, providing peace of mind and enduring performance. It is a refined, reliable fixture that perfectly complements a vision of lasting architectural integrity.', NULL, NULL, NULL),
(52, 4, 'ATLANTA', 'GKF5H-M1', 510, 355, 120, 'atlanta.png', NULL, NULL, NULL, NULL, 'ATLANTA', '', NULL, NULL, NULL),
(53, 4, 'CARIO', 'SK26H-M1', 355, 360, 125, 'cairo.png', NULL, NULL, NULL, NULL, 'CARIO', '', NULL, NULL, NULL),
(54, 4, 'DERBAN', 'RK06H-F1', 360, 360, 130, 'derban.png', NULL, NULL, NULL, NULL, 'DERBAN', '', NULL, NULL, NULL),
(55, 4, 'OPTION AVAILABLE', '', 0, 0, 0, 'marble_series_1.jpg', NULL, NULL, NULL, NULL, 'OPTIONS AVAILABLE', '', NULL, NULL, NULL),
(56, 4, 'OPTIONS AVAILABLES', '', 0, 0, 0, 'marble_series_2.jpg', NULL, NULL, NULL, NULL, 'OPTIONS AVAILABLES', '', NULL, NULL, NULL),
(57, 3, 'ART-ALBANY', 'RK10H-S1', 420, 340, 160, 'ART-ALBANY.png', NULL, NULL, NULL, NULL, 'ART-ALBANY', '', NULL, NULL, NULL),
(58, 3, 'ART-BRAZZAVILLE', 'SK04H-S1', 400, 400, 125, 'ART-BRAZZAVILLE.png', NULL, NULL, NULL, NULL, 'ART-BRAZZAVILLE', '', NULL, NULL, NULL),
(59, 3, 'ART-KEYSTONE', 'RK30H-S1', 350, 350, 110, 'ART-KEYSTONE.png', NULL, NULL, NULL, NULL, 'ART-KEYSTONE', '', NULL, NULL, NULL),
(60, 3, 'ART-MONACO', 'HK03H-S1', 590, 595, 140, 'ART-MONACO.png', NULL, NULL, NULL, NULL, 'ART-MONACO', '', NULL, NULL, NULL),
(61, 3, 'STONE OPTION AVAILABLE', '', 0, 0, 0, 'stone_series_1.jpg', NULL, NULL, NULL, NULL, 'STONE OPTION AVAILABLE', '', NULL, NULL, NULL),
(62, 3, 'STONE OPTIONS AVAILABLE', '', 0, 0, 0, 'stone_series_2.jpg', NULL, NULL, NULL, NULL, 'STONE OPTIONS AVAILABLE', '', NULL, NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
